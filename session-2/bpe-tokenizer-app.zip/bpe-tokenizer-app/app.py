"""
app.py — ERA V5 Session 2 assignment backend.

One Flask app that:
  - serves the frontend (static/index.html) at "/"
  - POST /api/train   -> fetches the 4 Wikipedia pages (or uses pasted text
                          overrides), trains a byte-level BPE tokenizer,
                          auto-rebalances across rounds, returns fertility
                          + spread + self-score
  - GET  /api/download/<kind>/<run_id>  -> tokenizer.json / vocab.txt / report.json

Run locally:   python app.py            (http://localhost:5000)
Deploy:        gunicorn app:app         (see requirements.txt)
"""

import json
import os
import time
import unicodedata
import uuid

from flask import Flask, Response, jsonify, request, send_from_directory

from tokenizer_core import (
    bytes_to_unicode,
    build_merge_rank,
    fertility_of,
    symbols_to_text,
    train_bpe,
)
from wiki_fetch import fetch_wiki_text

app = Flask(__name__, static_folder="static", static_url_path="")

# In-memory store of trained runs, keyed by run_id. Fine for an assignment
# demo; a free-tier host may restart the process and clear this, so the
# frontend keeps the run_id only for the current session's downloads.
RUNS = {}

DEFAULT_LANGS = {
    "en": {"label": "English", "code": "en", "title": "India"},
    "hi": {"label": "Hindi",   "code": "hi", "title": "भारत"},
    "te": {"label": "Telugu",  "code": "te", "title": "భారతదేశం"},
    "ta": {"label": "Tamil",   "code": "ta", "title": "இந்தியா"},
}

BYTE_TO_CHAR, CHAR_TO_BYTE = bytes_to_unicode()


@app.route("/")
def index():
    return send_from_directory(app.static_folder, "index.html")


@app.route("/api/languages")
def languages():
    return jsonify(DEFAULT_LANGS)


@app.route("/api/train", methods=["POST"])
def train():
    body = request.get_json(force=True, silent=True) or {}
    vocab_size = int(body.get("vocab_size", 10000))
    rounds = max(1, min(4, int(body.get("rounds", 2))))
    text_overrides = body.get("texts", {}) or {}
    lang_config = body.get("languages") or DEFAULT_LANGS

    lang_texts, lang_meta, errors = {}, {}, {}
    for key, cfg in lang_config.items():
        lang_meta[key] = {"label": cfg.get("label", key), "code": cfg.get("code", key)}
        override = (text_overrides.get(key) or "").strip()
        if len(override) > 200:
            lang_texts[key] = unicodedata.normalize("NFC", override)
            continue
        try:
            lang_texts[key] = fetch_wiki_text(cfg["code"], cfg["title"])
        except Exception as e:
            errors[key] = str(e)

    if errors:
        return jsonify({"error": "fetch_failed", "details": errors}), 400

    weights = {k: 1 for k in lang_texts}
    best = None
    round_log = []

    for rnd in range(rounds):
        vocab, merges = train_bpe(lang_texts, weights, vocab_size, BYTE_TO_CHAR)
        merge_rank = build_merge_rank(merges)
        fert = {k: fertility_of(t, merge_rank, BYTE_TO_CHAR) for k, t in lang_texts.items()}
        vals = [f["fertility"] for f in fert.values()]
        spread = max(vals) - min(vals)
        score = (1000 / spread) if spread > 0 else float("inf")

        result = {
            "round": rnd, "weights": dict(weights), "vocab": vocab, "merges": merges,
            "fert": fert, "spread": spread, "score": score,
        }
        round_log.append({"round": rnd, "spread": spread,
                           "score": (score if score != float("inf") else None)})
        if best is None or score > best["score"]:
            best = result

        worst_key = max(fert, key=lambda k: fert[k]["fertility"])
        best_key = min(fert, key=lambda k: fert[k]["fertility"])
        weights[worst_key] = weights.get(worst_key, 1) + 2
        if fert[best_key]["fertility"] < 1.5 and weights.get(best_key, 1) > 1:
            weights[best_key] -= 1

    run_id = uuid.uuid4().hex[:12]
    RUNS[run_id] = {**best, "lang_meta": lang_meta, "round_log": round_log,
                     "vocab_size_target": vocab_size, "created": time.time()}

    return jsonify({
        "run_id": run_id,
        "vocab_size": len(best["vocab"]),
        "fert": {k: {**v, **lang_meta[k]} for k, v in best["fert"].items()},
        "spread": best["spread"],
        "score": (best["score"] if best["score"] != float("inf") else None),
        "round_log": round_log,
    })


@app.route("/api/download/<kind>/<run_id>")
def download(kind, run_id):
    run = RUNS.get(run_id)
    if not run:
        return jsonify({"error": "run not found — retrain, this server may have restarted"}), 404

    if kind == "tokenizer":
        payload = {
            "vocab": {tok: i for i, tok in enumerate(run["vocab"])},
            "merges": run["merges"],
            "meta": {
                "vocab_size": len(run["vocab"]),
                "self_score": (run["score"] if run["score"] != float("inf") else None),
                "spread": run["spread"],
                "languages": list(run["lang_meta"].values()),
            },
        }
        return Response(
            json.dumps(payload, ensure_ascii=False, indent=2),
            mimetype="application/json",
            headers={"Content-Disposition": "attachment; filename=tokenizer.json"},
        )

    if kind == "vocab":
        lines = [f"{i}\t{symbols_to_text(tok, CHAR_TO_BYTE)}" for i, tok in enumerate(run["vocab"])]
        return Response(
            "\n".join(lines), mimetype="text/plain",
            headers={"Content-Disposition": "attachment; filename=vocab.txt"},
        )

    if kind == "report":
        report = {
            "vocab_size": len(run["vocab"]),
            "weights_used": run["weights"],
            "per_language": {run["lang_meta"][k]["code"]: v for k, v in run["fert"].items()},
            "spread": run["spread"],
            "self_score": (run["score"] if run["score"] != float("inf") else None),
            "round_log": run["round_log"],
        }
        return Response(
            json.dumps(report, ensure_ascii=False, indent=2),
            mimetype="application/json",
            headers={"Content-Disposition": "attachment; filename=report.json"},
        )

    return jsonify({"error": "unknown kind, use tokenizer|vocab|report"}), 400


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=False)
